---
title: Home
permalink: /
---

## Welcome

{{ site.description }}

## List Example

1. [Home]({{ '/' | relative_url }})
2. [Listings]('')
3. [Links]('')
4. [Tips]('')
5. [ZIP File]('')
6. [Tarball]('')
7. [GitHub]('')
8. [About]('')
9. [Web]('')

## Table Example

| A | B | C |
| A | B | C |
| A | B | C |

## Youtube Example

{% include youtube.html youtube_url='https://www.youtube.com/embed/OxbgFHSPvnI' %}

## Disclaimer

{% include disclaimer.html %}
